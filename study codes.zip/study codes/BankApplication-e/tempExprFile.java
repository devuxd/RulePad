CustomerController dummy_variable = 0;
